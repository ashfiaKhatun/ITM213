package sport_management;

import java.util.Scanner;

public class Main {
    
    public static void main(String[]args){
        
        Scanner input = new Scanner(System.in);
        
        SMS_Abstract abs;
        
        System.out.println("***Welcome to Airgun Championship 2022***");
        System.out.println();
        
        System.out.println("1. Registration");
        System.out.println("2. Event Schedule");
        
        System.out.println();
        
        System.out.print("Select your option: ");
        int select = input.nextInt();
        
        System.out.println();
        
/*____________________________________________________________________________*/
        
        //this part is working for registration
        
        if(select == 1){
            
        Registration reg = new Registration();
            
        System.out.print("First name: ");
        String f_name = input.next();
        reg.setF_name(f_name);
        
        System.out.print("Last name: ");
        String l_name = input.next();
        reg.setL_name(l_name);
        
        System.out.print("Age: ");
        int age = input.nextInt();
        reg.setAge(age);
        
        System.out.print("Gender (Male/ Female): ");
        String gender = input.next();
        reg.setGender(gender);
        
        System.out.print("Club name: ");
        reg.setClub_name(input.next());
        
        System.out.print("Mobile no: ");
        reg.setNum(input.nextInt());

        System.out.println();
        
        System.out.println("1. 10 Meter Air Rifle");
        System.out.println("2. 10 Meter Air Pistol");
        
        System.out.println();
        
        System.out.print("Enter Event No: ");
        int sl_num = input.nextInt();
        reg.event_reg(sl_num);
        
        System.out.println();
        
        reg.event_info();
        }
        
/*____________________________________________________________________________*/
        
        //this part is working to check schedule
        
        else if(select == 2){
            
            System.out.println("1. 10 Meter Air Rifle Men Junior");
            System.out.println("2. 10 Meter Air Rifle Men Senior");
            System.out.println("3. 10 Meter Air Rifle Women Junior");
            System.out.println("4. 10 Meter Air Rifle Women Senior");
            System.out.println("5. 10 Meter Air Pistol Men Junior");
            System.out.println("6. 10 Meter Air Pistol Men Senior");
            System.out.println("7. 10 Meter Air Pistol Women Junior");
            System.out.println("8. 10 Meter Air Pistol Women Senior");

            System.out.println();
            
            System.out.print("Enter event no: ");
            int serial = input.nextInt();
            
            abs = new Schedule(serial);
            
            System.out.println();
            
            abs.event_info();
        }

    }
    
}
