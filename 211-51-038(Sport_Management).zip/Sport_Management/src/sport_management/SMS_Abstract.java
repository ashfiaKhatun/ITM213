package sport_management;

public abstract class SMS_Abstract {
    
    String name;
    
    abstract void event_info();
    
}
