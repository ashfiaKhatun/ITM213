package sport_management;

public class Registration extends SMS_Abstract{
    
    private String f_name, l_name, gender, club_name;
    private int age, num;
    
    public String getF_name(){
        return f_name;
    }
    
    public void setF_name(String f_name){
        this.f_name = f_name;
    }
    
    public String getL_name(){
        return l_name;
    }
    
    public void setL_name(String l_name){
        this.l_name = l_name;
    }
    
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getClub_name() {
        return club_name;
    }

    public void setClub_name(String club_name) {
        this.club_name = club_name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
    
    int sl_num;
    
    public void event_reg(int sl_num){
        
        this.sl_num = sl_num;
    }

    
    public void display_1(){
        System.out.println("Name: "+f_name+" "+l_name);
        
    }
    
    /*____________________________________________________________________*/
    
    //Auto generated event name & schedule based on user input
    
    
    @Override
    public void event_info(){
        
        String gen_1 = "male";
        String gen_2 = "female";
        
        
        if(sl_num== 1){
            
            if(age == 21 || age<21 && gen_1.equalsIgnoreCase(gender)){
                
            display_1();
            System.out.println("Event name: 10 Meter Air Rifle Men Junior");
            System.out.println("Event Date: 01-12-2022, 09.00 AM");
            System.out.println();
            System.out.println("Registration successful");
            System.out.println();

            }
            
            else if(age>21 && gen_1.equalsIgnoreCase(gender)){
                
            display_1();
            System.out.println("Event name: 10 Meter Air Rifle Men Senior");
            System.out.println("Event Date: 01-12-2022, 03.00 PM");
            System.out.println();
            System.out.println("Registration successful");
            System.out.println();
            
            }
            
            else if(age == 21 || age<21 && gen_2.equalsIgnoreCase(gender)){
                
            display_1();
            System.out.println("Event name: 10 Meter Air Rifle Women Junior");
            System.out.println("Event Date: 02-12-2022, 09.00 AM");
            System.out.println();
            System.out.println("Registration successful");
            System.out.println();

            }
            
            else if(age>21 && gen_2.equalsIgnoreCase(gender)){
                
            display_1();
            System.out.println("Event name: 10 Meter Air Rifle Women Senior");
            System.out.println("Event Date: 02-12-2022, 03.00 PM");
            System.out.println();
            System.out.println("Registration successful");
            System.out.println();
            
            }
        }
        
        else if(sl_num==2){
            
            if(age == 21 || age<21 && gen_1.equalsIgnoreCase(gender)){
                
            display_1();
            System.out.println("Event name: 10 Meter Air Pistol Men Junior");
            System.out.println("Event Date: 03-12-2022, 09.00 AM");
            System.out.println();
            System.out.println("Registration successful");
            System.out.println();

            }
            
            else if(age>21 && gen_1.equalsIgnoreCase(gender)){
                
            display_1();
            System.out.println("Event name: 10 Meter Air Pistol Men Senior");
            System.out.println("Event Date: 03-12-2022, 03.00 PM");
            System.out.println();
            System.out.println("Registration successful");
            System.out.println();
            
            }
            
            else if(age == 21 || age<21 && gen_2.equalsIgnoreCase(gender)){
                
            display_1();
            System.out.println("Event name: 10 Meter Air Pistol Women Junior");
            System.out.println("Event Date: 04-12-2022, 09.00 AM");
            System.out.println();
            System.out.println("Registration successful");
            System.out.println();

            }
            
            else if(age>21 && gen_2.equalsIgnoreCase(gender)){
                
            display_1();
            System.out.println("Event name: 10 Meter Air Pistol Women Senior");
            System.out.println("Event Date: 04-12-2022, 03.00 PM");
            System.out.println();
            System.out.println("Registration successful");
            System.out.println();
            
            }
        
        }
        else{
            System.out.println("Enter number 1 or 2");
            
        }
        
    }

}
