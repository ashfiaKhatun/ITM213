package sport_management;

public class Schedule extends SMS_Abstract{
    
    int serial;
    
    Schedule(int serial){
        
        this.serial = serial;
    }
    
    
    @Override
    public void event_info(){
                
        if(serial== 1){
            System.out.println("Event name: 10 Meter Air Rifle Men Junior");
            System.out.println("Date: 01-12-2022, 09.00 AM");
            
        }
        else if(serial== 2){
            System.out.println("Event name: 10 Meter Air Rifle Men Senior");
            System.out.println("Date: 01-12-2022, 03.00 PM");
            
        }
        else if(serial==3){
            System.out.println("Event name: 10 Meter Air Rifle Women Junior");
            System.out.println("Date: 02-12-2022, 09.00 AM");
            
        }
        else if(serial==4){
            System.out.println("Event name: 10 Meter Air Rifle Women Senior");
            System.out.println("Date: 02-12-2022, 03.00 PM");
            
        }
        else if(serial==5){
            System.out.println("Event name: 10 Meter Air Pistol Men Junior");
            System.out.println("Date: 03-12-2022, 09.00 AM");
            
        }
        else if(serial==6){
            System.out.println("Event name: 10 Meter Air Pistol Men Senior");
            System.out.println("Date: 03-12-2022, 03.00 PM");
            
        }
        else if(serial==7){
            System.out.println("Event name: 10 Meter Air Pistol Women Junior");
            System.out.println("Date: 04-12-2022, 09.00 AM");
        }
            
        else if(serial==8){
            System.out.println("Event name: 10 Meter Air Pistol Women Senior");
            System.out.println("Date: 04-12-2022, 03.00 PM");
        }
            
        else{
            System.out.println("Enter number between 1 to 8");
            
        }
        
    
    }
    
            
}

